# 📑 Geração de Notas Técnicas da APS

Este repositório contém scripts em **R** para geração automatizada de notas técnicas da **Atenção Primária à Saúde (APS)**.  
O objetivo é preencher um template em R Markdown com informações de municípios (extraídas de planilhas Excel) e gerar relatórios formatados em **Word**.

---

## 📂 Estrutura do projeto

```
aps-notas-tecnicas/
 ├─ R/
 │   └─ gerar_relatorios.R   # Script principal em R
 ├─ modelo3.docx             # Template Word para formatação
 ├─ data/
 │   └─ exemplo.xlsx          # (opcional) Dados de exemplo
 ├─ .gitignore
 └─ README.md
```

---

## 🚀 Como usar

### 1. Pré-requisitos
Instale os pacotes necessários:

```r
install.packages(c(
  "flextable", "readxl", "dplyr", "glue", 
  "pander", "openxlsx", "stringi", "stringr", "rmarkdown"
))
```

### 2. Estrutura dos dados
O script espera um **dataframe `df`** carregado a partir de Excel, com colunas como:

- `uf`, `municipio`, `ivs`, `categoria_de_ivs`, `populacao`  
- `esf_qtde._esf_credenciadas`, `acs_total`, `emulti_valor_total_custeio`  
- `esb_valor_custeio_esb_40h`, `residencia_valor`, `bfa1_perc._cobertura_de_beneficiarios_acompanhados`  
- *(e outras variáveis listadas no script)*

> ⚠️ Os nomes das colunas precisam estar compatíveis com o `fill_template()`.

### 3. Executar
No R, rode:

```r
source("R/gerar_relatorios.R")

# Para cada linha do dataframe, será gerado um arquivo Rmd:
#   relatorio_NomeMunicipio.Rmd
```

Depois, renderize para Word:

```r
rmarkdown::render("relatorio_MunicipioX.Rmd",
                  output_format = "word_document",
                  output_file = "relatorio_MunicipioX.docx")
```

---

## 📝 Personalização

- O arquivo `modelo3.docx` define o estilo visual dos relatórios.  
- O template em R Markdown pode ser editado dentro do script (`template <- "..."`).  
- Caso queira traduzir para PDF ou HTML, basta mudar a opção no YAML do Rmd.

---

## 📌 Observações

- Os relatórios `.Rmd` e `.docx` **não devem ser versionados** (estão no `.gitignore`).  
- Apenas scripts, templates e exemplos de dados devem ser incluídos no repositório.  
- Os dados usados **não devem conter informações sensíveis**.

---

## 📜 Licença

Este projeto está sob a licença [MIT](LICENSE).
