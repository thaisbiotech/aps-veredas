# gerar_relatorios.R
# Autor: Thaís Barbosa
# Objetivo: Preencher template R Markdown com dados de Excel e gerar relatórios Word

library(flextable)
library(readxl)
library(dplyr)
library(glue)
library(pander)
library(openxlsx)
library(stringi)
library(stringr)
library(rmarkdown)


# Carregar o arquivo Excel
df[is.na(df)] <- "N/A"

# Definir o template para o documento R Markdown
template <- "
---
output: 
  word_document:
    reference_docx: /cloud/project/modelo3.docx
---

## Nota Técnica

<p>&nbsp;<p>
# **Assunto**: Informações de ações e programas da Atenção Primária à Saúde (APS)

# **1.Informações Sociodemográficas** 

* Unidade Federativa: {uf}

* Município: {municipio}
 
* Índice de Vulnerabilidade Social (IVS): {ivs} - {cat_ivs}

* Índice de Equidade de Dimensionamento (IED): {ied}

* População (IBGE 2022): {populacao}

* População quilombola (IBGE 2022): {quilombola}

* População indígena em contexto urbano (IBGE 2022): {ind_urb}

* População indígena em território indígena (IBGE 2022): {ind_ald}

# **2.Informações das equipes de Saúde da Família (eSF), das de atenção Primária (eAP) e de Agentes Comunitários de Saúde (ACS)**




**Quadro 1** – Distribuição de eSF, eAP e ACS

| Equipes e ACS | Teto (n)   | Credenciadas (n) | Homologadas (n) | Custeadas (n) | Valor mensal do repasse (R$)
|:-------------:|:----------:|:----------------:|:---------------:|:-------------:|:-------------:|
| eSF           | {teto_esf} | {esf_cred}       | {esf_homol}     | {esf_pagas}   |{valor_esf}    |
| eAP           | {teto_eap} | {eap_cred}       | {eap_homol}     | {eap_pagas}   |{valor_eap}    |
| ACS           | {teto_acs} | {acs_cred}       |        -        |    {acs_pg}  |{valor_acs_dir} |
<p>&nbsp;<p>

O total de ACS com vínculo indireto é de **{ind_acs}**, com um total de repasse de **{valor_acs_ind}**.



# **3.Informações das equipes Multiprofissionais (eMulti)**
**Quadro 2** – Distribuição de eMulti

| eMulti        |Credenciadas (n) | Homologadas (n) | Custeadas (n) | Valor mensal do repasse (R$)| 
|:-------------:|:---------------:|:---------------:|:-------------:|:---------------------------:|
| Total         | {emulti_cred}   | { emulti_homol} |{emulti_pagas} |    { emulti_valor}          |

<p>&nbsp;</p>

As modalidades de eMulti custeadas são:

* eMulti ampliada: {emulti_ampli};
* eMulti complementar: {emulti_comple};
* Multi estratégica: {emulti_est};
* eMulti interminicipal: {emulti_inter}.
<p>&nbsp;</p>
Tem-se **{emulti_tic}** eMulti com atendimento atendimento mediado por TIC.

# **4.Informações do Brasil Sorridente**
**Quadro 3** – Distribuição de eSB e UOM

| Equipes             | Credenciadas (n) | Homologadas (n) | Custeadas (n) |Valor mensal do repasse (R$)|
|:-------------------:|:----------------:|:---------------:|:-------------:|:--------------------------:|
| eSB 40h             |{esb40h_cred}     |{esb40h_homol}   |{esb40h_pagas} |{esb40h_valor}              |
| eSB CH diferenciada |{esbch_cred}      |{esbch_homol}    |{esbch_pagas}  |{esbch_valor}               |
| UOM                 |{uom_cred}        |{uom_homol}      |{uom_pagas}    |{uom_valor}                 |

<p>&nbsp;</p>

As modalidades de eSB custeadas são:

* eSB 40 horas - modalidade I: {esb40hi};
* eSB 40 horas - modalidade II: {esb40hii};
* eSB 30 horas (carga horária diferenciada): {esbch30h};
* eSB 20 horas (carga horária diferenciada): {esbch20h}.

<p>&nbsp;</p>

Para a estratégia CEO, tem-se o repasse de **{ceo_est}** para o nível estadual e **{ceo_mun}** para o nível municipal. Para LRPD, tem-se **{lrpd_est}** para o nível estadual e **{lrpd_mun}** para o municipal. No que se refere ao SESB, tem-se **{sesb_cust}** repassados.

# **5.Informações das equipes/estratégias direcionadas a populações específicas**

**Quadro 4** – Distribuição do custeio por eSFR, UBSF e microscopistas

| Equipe e estratégias   | Credenciadas (n)  | Homologadas (n)   | Custeadas (n)   |Valor mensal do repasse (R$)| 
|:----------------------:|:-----------------:|:-----------------:|:---------------:|:--------------------------:|
| eSFR                   |{esfr_cred}        |{esfr_homol}       |{esfr_paga}      |{esfr_valor}                |
| UBSF                   |{ubsf_cred}        |{ubsf_homol}       |{ubsf_valor}     |{ubsf_valor}                |
| Microscopistas         |{microscop_cred}   |Não se aplica      |{microscop_pagos}|{microscop_valor}           |

<p>&nbsp;<p>

**Quadro 5** – Distribuição do custeio de eCR

| eCR        | Credenciadas (n)   | Homologadas (n)   | Custeadas (n)   |Valor mensal do repasse (R$)| 
|:----------:|:------------------:|:-----------------:|:---------------:|:--------------------------:|
| Total      |{ecr_cred}          |{ecr_homol}        |{ecr_pagas}      |{ecr_valor}                 |
<p>&nbsp;</p>

As modalidades de eCR custeadas são:

* eCR - modalidade I: {ecr_i};
* eCR - modalidade II: {ecr_ii};
* eCR - modalidade III: {ecr_iii}.


**Quadro 6** – Distribuição do custeio de eAPP

| Equipes                |  Credenciadas (n)  |Custeadas (n)  |Valor mensal do repasse (R$)| 
|:----------------------:|:------------------:|:-------------:|:--------------------------:|
| eAPP estadual          |{eapp_est_cred}     |{eapp_est_paga}|{eapp_est_valor}            |
| eAPP municipal         |{eapp_mun_cred}     |{eapp_mun_paga}|{eapp_mun_valor}            |

<p>&nbsp;</p>

O custeio para a PNAISARI é de **{pnaisari_valor}**.

# **6.Incentivo à Atividade Física (IAF) e Programa Academia da Saúde (PAS)**

**Quadro 7** – Distribuição do custeio de IAF e PAS

| Estratégia   | Estabelecimentos credenciados (n)   | Estabelecimentos custeados (n) |Valor mensal do repasse (R$)|  
|:------------:|:-----------------------------------:|:------------------------------:|:--------------------------:|
| IAF          |{iaf_cred}                           |{iaf_pagas}                     |{iaf_valor}                 |
| PAS          |{pas_cred}                           |{pas_pagas}                     |{pas_valor}                 |


# **7.Incentivo às residências em saúde**
**Quadro 8** – Distribuição do custeio de incentivo às residências

| Categoria              | Homologados (n)    | Custeados (n)      |  
|:----------------------:|:------------------:|:------------------:|
| Medicina               |{res_med_homol}     |{res_med_pg}        |
| Enfermagem             |{res_enf_homol}     |{res_enf_pg}        |
| Cirurgião-dentista     |{res_cd_homol}      |{res_cd_pg}         |

<p>&nbsp;<p>

O valor registrado de cofinanciamento para essa estratégia é de **{res_valor}**.

# **8.Programa Saúde na Escola (PSE) ciclo 2023-2024**

* Total de escolas participantes: {escolas};
* Total de educandos: {educandos}.

# **9.Acompanhamento das Condicionalidades do Programa Bolsa Família**

O município possui **{bfa1_acomp}** beneficiários a serem acompanhados pela APS, dos quais foram acompanhados **{bfa1_acomp_c}** beneficiários, com um alcance de **{bfa1_perc}%**. No que concerne à população quilombola, tem-se **{bfa2_acomp}** beneficiários a serem acompanhados, com um alcance de **{bfa2_acomp_c}** dessa população.  Tratando-se da população indígena, identificou-se **{bfa3_acomp}**  beneficiários, com **{bfa3_acomp_c}** acompanhados, representando **{bfa3_perc}%** de alcance.

# **10.Sistema de Informação em Saúde para a Atenção Básica (SISAB)**

O território utiliza, predominantemente, o **{sistema}**.

# **11.Provimento** 

O Programa Mais Médicos (PMM) e o Programa Mais Médicos pelo Brasil são políticas públicas que enfrentam o desafio para a melhoria do atendimento aos usuários do SUS. O programa leva médicos para regiões prioritárias, remotas, de difícil acesso e de alto índice de vulnerabilidade, onde há escassez ou ausência desses profissionais.

<p>&nbsp;<p>

O território conta com:

* Vagas ativas (PMM e PMMB): {vagas_ativas}, com {vagas_federal} vagas com financiamento federal e {vagas_copart} com coparticipação;
* Vagas desocupadas (PMM e PMMB):  {vagas_desocu}.

# **12.Rede Alyne**
<p>Para qualificar a atenção à saúde materna e infantil, especialmente para gestantes, puérperas e recém-nascidos, o Governo Federal instituiu a Rede Alyne. O nome homenageia a jovem negra Alyne Pimentel, que faleceu aos 22 anos, então no sexto mês de gravidez, em decorrência de negligência assistencial. Com novos incentivos para pré-natal, aleitamento materno, leitos canguru e serviços de urgência e emergência, a Rede Alyne tem como meta reduzir a mortalidade materna geral em 25% e de mulheres negras em 50% até 2027.</p> 

<p>&nbsp;</p>
<p>Em novembro de 2024, o Governo Federal repassou recursos para que os municípios e o Distrito Federal adquirissem kits de teste rápido de gravidez (TRG), com o objetivo de garantir que estes exames estivessem disponíveis em todos os serviços da APS, mesmo em territórios remotos.  O Governo Federal também repassou recursos referentes aos exames de pré-natal, com um custeio que abarcou testes rápidos de sífilis, HIV, Hepatite B e C, teste sorológico para HTLV, ultrassom, entre outras análises clínicas. Para os exames TRG, o município recebeu **{alyne1}** e, para os demais testes rápidos e análises clínicas, **{alyne2}**.</p> 

# **13.Novo PAC**

O Novo PAC é um programa de investimentos coordenado pelo governo federal, em parceria com o setor privado, estados, municípios e movimentos sociais. Todo o esforço conjunto é para acelerar o crescimento econômico e a inclusão social, gerando emprego e renda, e reduzindo desigualdades sociais e regionais. Dentre os eixos do Novo PAC, tem-se o de investimento em saúde. Nesse âmbito, o município recebeu **{novo_pac}** para a construção de UBS. 

# **14.Possibilidades**

EM CONSTRUÇÃO. 

# **15.Referências**


EM CONSTRUÇÃO. 


"
# Função para preencher o template com dados de uma linha do dataframe
fill_template <- function(row) {
  print(row)
  return(glue::glue(template,
                    uf = row$uf,
                    municipio = row$municipio,
                    ivs = row$ivs,
                    ied = row$esf_indicador_de_equidade_e_dimensionamento,
                    populacao = row$populacao,
                    quilombola = row$quilombola,
                    ind_urb = row$ind_urb,
                    ind_ald = row$ind_ald,
                    teto_esf = row$teto_esf,
                    esf_cred = row$esf_qtde._esf_credenciadas,
                    esf_homol = row$esf_qtde._esf_com_portaria_de_homologacao,
                    esf_pagas = row$esf_qtde._esf_pagas,
                    esf_valor = row$esf_valor_total_esf,
                    teto_eap = row$eap_qtde._eap_credenciadas,
                    eap_cred = row$eap_qtde._eap_credenciadas,
                    eap_homol = row$eap_qtde._eap_com_portaria_de_homologacao,
                    eap_pagas = row$eap_qtde._eap_pagas,
                    eap_valor = row$eap_valor__total_eap,
                    teto_acs = row$teto_acs,
                    acs_cred= row$acs_qt_acs_credenciado,
                    acs_pg= row$acs_dir_qt,
                    ind_acs= row$acs_ind_qtde._acs_pago,
                    cat_ivs= row$categoria_de_ivs,
                    valor_esf= row$esf_valor_total_esf,
                    valor_eap= row$eap_valor__total_eap,
                    valor_acs_dir= row$acs_total,
                    valor_acs_ind= row$acs_ind_total,
                    emulti_cred= row$emulti_qtde._emulti_credenciadas,
                    emulti_homol= row$emulti_qtde._emulti_com_portaria_de_homologacao,
                    emulti_pagas= row$emulti_qtde._emulti_total_pagas,
                    emulti_ampli= row$emulti_qt._emulti_ampliada_pagas,
                    emulti_inter= row$emulti_qt._emulti_intermunicipal_pagas,
                    emulti_comple= row$emulti_qt._emulti_complementar_pagas,
                    emulti_est= row$emulti_qt._emulti_estrategica_pagas,
                    emulti_tic= row$emulti_custeio_manutencao_atendimento_remoto,
                    emulti_valor= row$emulti_valor_total_custeio,
                    esb40h_cred= row$esb_qtde._esb_40h_credenciada,
                    esb40h_homol= row$esb_qtde._esb_40h_com_portaria_de_homologacao,
                    esb40h_pagas = row$esb40h_total_pagas,
                    esb40h_valor= row$esb_valor_custeio_esb_40h,
                    esbch_cred= row$esb_qtde._esb_ch_diferenciada_credenciada,
                    esbch_homol= row$esb_qtde._esb_ch_diferenciada_com_portaria_de_homologacao,
                    esbch_pagas= row$esbch_total_pagas,
                    esbch_valor= row$esb_valor_custeio_esb_ch_diferenciada,
                    esb40hi= row$esb_qt._esb_40h_modalidade_i_pagas,
                    esb40hii= row$esb_qt._esb_40h_modalidade_ii_pagas,
                    esbch20h= row$esbch20h_pagas ,
                    esbch30h= row$esbch30h_pagas,
                    uom_cred= row$uom_qt._uom_credenciada,
                    uom_homol= row$uom_qt._uom_com_portaria_de_homologacao,
                    uom_pagas= row$uom_qt._uom_paga,
                    uom_valor= row$uom_valor_custeio,
                    ceo_mun= row$ceo_ceo_municipal,
                    ceo_est= row$ceo_ceo_estadual,
                    lrpd_mun= row$lrpd_lrpd_municipal,
                    lrpd_est= row$lrpd_lrpd_estadual,
                    sesb_cust= row$sesb_custeio,
                    ecr_cred= row$ecr_qtde._ecr_credenciadas,
                    ecr_homol= row$ecr_qtde._ecr_com_portaria_de_homologacao,
                    ecr_pagas= row$ecr_tot_pagas,
                    ecr_i= row$ecr_qtde._ecr_modalidade_i_pagas,
                    ecr_ii= row$ecr_qtde._ecr_modalidade_ii_pagas,
                    ecr_iii= row$ecr_qtde._ecr_modalidade_iii_pagas,
                    ecr_valor= row$ecr_valor,
                    esfr_cred= row$esfr_qtde._esfrb_credenciado,
                    esfr_homol= row$esfr_qtde._esfrb_com_portaria_de_homologacao,
                    esfr_paga= row$esfr_qtde._esfrb_pago,
                    esfr_valor= row$esfr_custeio,
                    ubsf_cred= row$ubsf_qtde._ubsf_credenciado,
                    ubsf_homol= row$ubsf_qtde._ubsf_com_portaria_de_homologacao,
                    ubsf_valor= row$ubsf_custeio,
                    microscop_cred= row$microscopista_qtde._microscopista_credenciado,
                    microscop_pagos= row$microscopista_qtde._microscopista_pago,
                    microscop_valor= row$microscopista_valor,
                    eapp_mun_cred= row$eapp_qtde._eapp_municipal_credenciada,
                    eapp_mun_paga= row$eapp_qtde._eapp_municipal_paga,
                    eapp_mun_valor= row$eapp_valor_eapp_municipal,
                    eapp_est_cred= row$eapp_qtde._eapp_estadual_credenciada,
                    eapp_est_paga= row$eapp_qtde._eapp_estadual_paga,
                    eapp_est_valor= row$eapp_valor_eapp_estadual,
                    pnaisari_valor= row$pnaisari_valor,
                    iaf_cred= row$iaf_qtde._estabelecimentos_credenciados,
                    iaf_pagas= row$iaf_qtde._estabelecimentos_pagos,
                    iaf_valor= row$iaf_valor,
                    pas_cred= row$academia_da_saude_qtde._estabelecimentos_credenciados,
                    pas_pagas= row$academia_da_saude_qtde._estabelecimentos_pagos,
                    pas_valor= row$academia_da_saude_valor,
                    res_med_homol= row$residencia_qt._medico_residente_homologado,
                    res_med_pg= row$residencia_qt._medico_residente_pago,
                    res_enf_homol= row$residencia_qt._enfermeiro_residente_homologado,
                    res_enf_pg= row$residencia_qt._enfermeiro_residente_pago,
                    res_cd_homol= row$residencia_qt._cirurgiao_dentista_residente_homologado,
                    res_cd_pg= row$residencia_qt._cirurgiao_dentista_residente_pago,
                    res_valor= row$residencia_valor,
                    escolas= row$escolas,
                    educandos= row$educandos,
                    bfa1_acomp= row$bfa1_qtd._beneficiarios_a_serem_acompanhados,
                    bfa1_acomp_c= row$bfa1_qtd._beneficiarios_acompanhados,
                    bfa1_perc= row$bfa1_perc._cobertura_de_beneficiarios_acompanhados,
                    bfa2_acomp= row$bfa2_qtd._beneficiarios_a_serem_acompanhados,
                    bfa2_acomp_c= row$bfa2_qtd._beneficiarios_acompanhados,
                    bfa2_perc= row$bfa2_perc._cobertura_de_beneficiarios_acompanhados,
                    bfa3_acomp= row$bfa3_qtd._beneficiarios_a_serem_acompanhados,
                    bfa3_acomp_c= row$bfa3_qtd._beneficiarios_acompanhados,
                    bfa3_perc= row$bfa3_perc._cobertura_de_beneficiarios_acompanhados,
                    sistema= row$predominancia,
                    vagas_ativas= row$total_ativas,
                    vagas_desocu= row$vagas_desocupadas,
                    vagas_federal= row$vagas_ativas_federal,
                    vagas_copart= row$vagas_ativas_copart,
                    alyne1= row$impact_alyne1,
                    alyne2= row$impact_alyne2,
                    novo_pac= row$valor_pac_ubs ))
}

# Gerar um relatório para cada município
for (i in 1:nrow(df)) {
  report <- fill_template(df[i, ])
  writeLines(report, paste0("relatorio_", df$municipio[i], ".Rmd"))
}


